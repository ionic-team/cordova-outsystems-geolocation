import Capacitor
import CoreFoundation
import IONNativeIslandsLib
import UIKit

/// Capacitor marshalling shell for the shared Native Islands controller.
@objc(NativeIslandsPlugin)
public class NativeIslandsPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "NativeIslandsPlugin"
    public let jsName = "NativeIslands"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "applyLayout", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "command", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "reset", returnType: CAPPluginReturnPromise)
    ]

    private lazy var controller = NativeIslandsController(
        events: { [weak self] event, payload in
            self?.notifyListeners(event, data: payload)
        }
    )

    override public func load() {
        controller.ensureContainer(webView: webView)
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(hostDidResume),
            name: UIApplication.didBecomeActiveNotification,
            object: nil
        )
        if UIApplication.shared.applicationState == .active {
            controller.onHostResume()
        } else {
            controller.onHostPause()
        }
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(hostDidPause),
            name: UIApplication.willResignActiveNotification,
            object: nil
        )
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
        controller.dispose()
    }

    @objc func applyLayout(_ call: CAPPluginCall) {
        guard let payload = validateOperation(
            call,
            operation: "applyLayout",
            layout: true
        )
        else {
            return
        }
        guard
            let components = payload["components"] as? [[String: Any]],
            let scrollContainers = payload["scrollContainers"] as? [[String: Any]],
            let order = payload["order"] as? [String],
            let exclusions = payload["exclusions"] as? [String: Any],
            let cutouts = payload["cutouts"] as? [String: Any]
        else {
            call.reject(
                "layout envelope must contain component, scroll container, order, exclusion, and cutout fields",
                "invalid_request"
            )
            return
        }
        if let reason = controller.validateLayout(
            components: components,
            scrollContainers: scrollContainers,
            order: order,
            exclusions: exclusions,
            cutouts: cutouts
        ) {
            call.reject(reason, "invalid_request")
            return
        }
        controller.applyLayout(
            components: components,
            scrollContainers: scrollContainers,
            order: order,
            exclusions: exclusions,
            cutouts: cutouts,
            failure: { code, message in
                call.reject(message, code)
            },
            completion: {
                call.resolve()
            }
        )
    }

    @objc func command(_ call: CAPPluginCall) {
        guard let payload = validateOperation(call, operation: "command")
        else {
            return
        }
        guard
            let version = strictInteger(payload["protocolVersion"]),
            let island = payload["island"] as? String,
            let component = payload["islandType"] as? String,
            let method = payload["method"] as? String
        else {
            call.reject("command envelope is incomplete", "invalid_request")
            return
        }
        let params: [String: Any]
        if let rawParams = payload["params"] {
            guard let object = rawParams as? [String: Any] else {
                call.reject(
                    "command params must be an object",
                    "invalid_request"
                )
                return
            }
            params = object
        } else {
            params = [:]
        }
        controller.dispatchCommand(
            version: version,
            island: island,
            requestedType: component,
            method: method,
            params: params
        ) { result in
            if let code = result["code"] as? String {
                call.reject(
                    result["error"] as? String ?? code,
                    code
                )
            } else {
                call.resolve()
            }
        }
    }

    @objc func reset(_ call: CAPPluginCall) {
        guard validateOperation(call, operation: "reset") != nil else {
            return
        }
        controller.reset {
            call.resolve()
        }
    }

    @objc private func hostDidResume() {
        controller.onHostResume()
    }

    @objc private func hostDidPause() {
        controller.onHostPause()
    }

    private func validateOperation(
        _ call: CAPPluginCall,
        operation: String,
        layout: Bool = false
    ) -> [String: Any]? {
        guard let payload = call.options as? [String: Any] else {
            call.reject("operation payload must be an object", "invalid_request")
            return nil
        }
        let failure = layout
            ? controller.validateLayoutOperation(payload)
            : controller.validateOperation(operation, payload: payload)
        if let failure {
            let code = failure["code"] as? String ?? "invalid_request"
            call.reject(failure["error"] as? String ?? code, code)
            return nil
        }
        return payload
    }

    private func strictInteger(_ value: Any?) -> Int? {
        guard
            let number = value as? NSNumber,
            CFGetTypeID(number) != CFBooleanGetTypeID()
        else {
            return nil
        }
        let doubleValue = number.doubleValue
        guard
            doubleValue.isFinite,
            doubleValue.rounded(.towardZero) == doubleValue,
            doubleValue >= Double(Int.min),
            doubleValue <= Double(Int.max)
        else {
            return nil
        }
        return Int(doubleValue)
    }
}
