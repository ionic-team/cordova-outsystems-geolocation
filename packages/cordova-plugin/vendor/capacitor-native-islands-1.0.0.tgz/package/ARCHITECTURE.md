# Architecture

Native Islands has four parts:

1. A custom element renders in browsers, reads CSS and attributes, and emits DOM events.
2. The web runtime measures layout and paint order, then produces a platform-neutral
   composition plan.
3. A Capacitor or Cordova transport carries that plan through the platform's standard
   plugin bridge.
4. The Android and iOS runtimes host component views, route input, and apply the plan.

Component plugins register the native factory and define the matching custom element.
Application code uses the element and ordinary CSS. Native Islands does not include a
component library or require a framework-specific adapter.

## Composition

The WebView sits between native underlay and overlay hosts. Underlay components are
revealed through runtime-owned web knockout paths or alpha masks. Overlay components use native
cutouts for bounded opaque web paint above them. Keeping the WebView as one layer lets
normal CSS stacking contexts and `z-index` remain the source of truth.

On Android, an opaque solid document canvas can be painted by the native host while
the runtime makes the body canvas transparent. This keeps an underlay visible when
an inner scroller returns to its starting position. The web runtime enables it only
when the native session advertises support for the canvas color field.

Host plane and coordinate space are independent. A viewport island may move to
the underlay plane when higher web paint needs transparency, provided its lower
web knockouts remain stationary relative to their paint. Lower native overlays
move with it when necessary to preserve CSS order. This does not add a scroll
refresh loop or change native component identity.

`composition-audit.ts` checks whether detached native pixels can reproduce the
element's current CSS. Unsupported transforms, effects, clipping, or shapes suspend
the affected native component. Native platforms never substitute web pixels.

## Scrolling

Document scrolling stays native on both platforms and sends no bridge messages after
layout. Independent element scrollers use platform-specific implementations:

- iOS matches supported DOM scrollers to native child `UIScrollView` instances and
  observes their offsets.
- Android streams complete offset vectors for supported vertical inner scrollers.
  They carry the layout generation and are applied by native to the mounted views;
  scroll gestures do not trigger new layout plans. The WebView root routing mode
  remains available to transports that select it.

## Input

The layout plan contains separate visual cutouts and touch exclusions. At pointer-down,
the native container chooses the top eligible web or native target. That target owns
the complete gesture.

## Bridge boundary

The bridge carries layout, settled inner-scroll offsets where needed, component
`create` and `update` commands, reset, and native events. Payloads include a protocol
version because the web package and native libraries are released separately. Native
code validates the version, identifiers, structure, depth, and size before allocating
views or invoking component code.

The transport abstraction is internal. It allows the same runtime to use Capacitor,
Cordova, or a feature plugin that carries Native Islands transitively. A single global
runtime prevents two consuming plugins from creating competing composition hosts.

## Public boundary

The root package exports only `defineNativeIsland` and its option type. Component
commands remain `create` and `update`; native component factories remain app or
component-plugin code. `renderFallback` is only the browser implementation and the
source for optional web-owned accessibility semantics.
