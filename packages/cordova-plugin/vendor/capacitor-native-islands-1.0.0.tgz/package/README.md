# @capacitor/native-islands

Native Islands lets a Capacitor app place an Android `View` or iOS `UIView` where a
custom HTML element appears in the page. The element's CSS controls its size,
position, stacking order, and rounded corners. The native view follows the document
when it scrolls, and web and native controls keep the same visual and touch order.

This package contains the composition runtime and Capacitor bridge. It does not
ship a component library, demo component, renderer engine, or Capacitor fork.

See [ARCHITECTURE.md](ARCHITECTURE.md) for the package boundaries and platform
differences.

## How it fits together

Native Islands separates component implementation from component use:

1. A component author defines a custom element, such as `<app-map>`, and implements
   the native view for each supported platform.
2. An application developer uses that element like ordinary HTML and controls its
   layout with CSS.
3. Native Islands places the registered native view at the element's location.
   Browsers without a native transport render the element's web implementation.

A component plugin can package the web definition and its native implementations. In
that case, an application developer installs the component plugin and does not need
to register the native view or understand the Native Islands bridge.

## Install

Install this package directly only when your application or component plugin defines
its own native components:

```sh
npm install @capacitor/native-islands
npx cap sync
```

No Native Islands block is required in `capacitor.config`.

When using a component plugin that already includes Native Islands, follow that
plugin's installation instructions instead. The application should not install or
configure Native Islands separately unless the component plugin says otherwise.

## Use a component in an application

After installing a component plugin, use its custom element in normal markup. The
plugin documents its available attributes, properties, and events.

```html
<app-map
  latitude="41.1579"
  longitude="-8.6291"
  style="display:block;height:280px;border-radius:24px;z-index:2"
></app-map>
```

CSS controls the element's layout and stacking just as it would for a web element.
Changing a documented attribute updates the native component. Native component
events arrive as ordinary DOM events.

## Define the custom element

This section and the native registration section are for component authors. An
application developer using an existing component plugin can use the element and
skip both sections.

Call `defineNativeIsland` once from browser entry-point code, such as `src/main.ts`:

```ts
import { defineNativeIsland } from '@capacitor/native-islands';

defineNativeIsland({
  tagName: 'app-map',
  nativeComponent: 'app.map',
  isInteractive: true,
  observedAttributes: ['latitude', 'longitude'],
  getProperties: (element) => ({
    latitude: Number(element.getAttribute('latitude')),
    longitude: Number(element.getAttribute('longitude')),
  }),
  renderFallback: (element) => {
    const latitude = Number(element.getAttribute('latitude'));
    const longitude = Number(element.getAttribute('longitude'));
    const link = document.createElement('a');
    link.href = `https://www.openstreetmap.org/?mlat=${latitude}&mlon=${longitude}`;
    link.textContent = 'Open location in a web map';
    element.replaceChildren(link);
  },
  events: {
    cameraChanged: 'camerachanged',
  },
});
```

In this definition:

- `tagName` is the HTML tag used by the application.
- `nativeComponent` is the name registered by the Android and iOS code.
- `getProperties` converts HTML attributes and styles into values for the native
  component.
- `renderFallback` renders usable content in a normal browser and supplies hidden
  accessibility semantics when accessibility is web-owned.
- `events` maps events emitted by the native component to DOM event names. Here,
  native `cameraChanged` becomes the `camerachanged` DOM event.

The runtime sends `create` when the element connects and `update` when observed
attributes change. Attribute changes in the same task are coalesced into one update.
Those are the only component commands. A rejected native command emits the bubbling,
composed `nativeislanderror` event and never substitutes web pixels.

The custom element is also the native view's layout placeholder. Its position and
dimensions come from normal browser layout; the application does not send separate
native coordinates.

Component plugins can also list resolved CSS properties in `observedStyles`.
Changes caused by inline styles, classes, inherited custom properties, stylesheets,
or common system appearance preferences are coalesced into `update`. Read those
values with `getComputedStyle(element)` inside `getProperties`.

Observed attributes also expose reflected string properties when the name does not
collide with a built-in element property. Assigning `element.label = value` therefore
reaches the same attribute contract. `null` and `undefined` remove the attribute;
convert numbers, booleans, and structured values in `getProperties`.

DOM reparenting in the same task preserves the native identity and does not
send `create` again. An element rendered before its consuming plugin's native side
is ready uses its browser implementation, then activates once when the plugin initializes.

`renderFallback` is required. It must replace or update its complete output every
time it runs so repeated calls do not duplicate content. Avoid closing over the
custom-element instance. The runtime calls it on browser mount, after browser-side
attribute changes, and for web-owned accessibility.

Accessibility is web-owned by default. While native composition is active, the
runtime calls `renderFallback` with a visually hidden semantic container and hides
the native subtree from accessibility. If a component instead registers its native
factory with native accessibility, set `accessibility: 'native'` in the web
definition too. The web and native registrations must agree so only one
representation is exposed to assistive technologies.

Use lowercase kebab-case for custom-element tags, HTML attributes, and DOM event
names. Convert attributes to camelCase only in the JavaScript/native property object.
Native registry names use a stable dotted namespace such as `app.map`.

## Register the native component

The web definition uses `nativeComponent: 'app.map'` to request a native view.
Register a factory with that exact name on each supported platform. A factory is the
function that creates the platform's `NativeIsland` implementation.

Register it once during app or plugin startup, before an `<app-map>` element connects
to the document.

### iOS

Register from a Capacitor plugin's `load()` method or during app startup:

```swift
import IONNativeIslandsLib

NativeIslandsRegistry.register(componentName: "app.map") {
    AppMapIsland()
}
```

`AppMapIsland` implements `NativeIsland` and provides the `UIView` displayed by the
custom element. See the
[iOS runtime guide](https://github.com/ionic-team/ion-ios-native-islands#register-a-native-component)
for a complete component implementation.

### Android

Register from a Capacitor plugin's `load()` method or during app startup:

```kotlin
import io.ionic.libs.ionnativeislandslib.NativeIslandsRegistry

NativeIslandsRegistry.register(componentName = "app.map") { context, _ ->
    AppMapIsland(context)
}
```

`AppMapIsland` implements `NativeIsland` and provides the Android `View`. Native
Islands supplies the `Context` when it creates the component. See the
[Android runtime guide](https://github.com/ionic-team/ion-android-native-islands#register-a-native-component)
for a complete component implementation.

If a component plugin owns the native view, the plugin should perform both
registrations itself. Application developers can then install the component plugin
and use `<app-map>` without writing Swift or Kotlin registration code.

The controller calls `create(properties)` when the native view mounts and
`update(properties)` when an observed attribute or style changes.

## Web layers and z-index

Native Islands follows the browser's stacking contexts and `z-index`. Application
authors use ordinary HTML and CSS; they do not declare native/web layers or call a
stacking API.

The runtime automatically recognizes bounded elements whose computed background
fully covers their border box. It compares those surfaces with each island in the
browser's real paint order and sends only the intersections that need native visual
or touch cutouts.

```html
<div style="position:relative;height:300px">
  <div aria-hidden="true" style="position:absolute;inset:0;z-index:1;background:#eef2f7"></div>
  <app-map style="position:absolute;inset:20px;z-index:2"></app-map>
  <button style="position:absolute;right:36px;bottom:36px;z-index:3">Recenter</button>
</div>
```

For an advanced component integration, `data-native-islands-opaque-surface` can
confirm that a bounded surface the browser cannot classify, such as a fully opaque
image, is safe to treat as opaque. It does not change paint order. Ordinary app
screens should not need it. When a composition cannot be represented safely, the
affected native component becomes inactive and receives
`data-native-islands-inactive`; it is not replaced with web content.

Translucent web paint and shadows can remain above a native island by placing it
below the WebView and removing only lower web paint. The runtime chooses this
automatically when those knockout holes stay aligned without scroll-driven
JavaScript updates. In particular, a fixed island can use this path over a
document with no root scroll range; a fixed hole through a scrolling document
still fails closed. Overlapping rounded underlays use an alpha-mask union so
their shared region remains transparent.

Component plugins set `requiresUnobscuredSurface: true` for protected system
surfaces that the application compositor cannot clip. If another surface would
obscure one, Native Islands suspends that native component until the overlap clears.

## Rounded corners

A uniform pixel CSS `border-radius` on the custom element is detected automatically,
sent to native, and used for both clipping and touch routing. Component users do not
need a separate radius property, and no radius is required for a rectangular element.
Non-uniform, elliptical, percentage-based, or disconnected shapes are unsupported.

## Scrolling and touch

Document scrolling is observed and applied natively. Island document coordinates
cross the bridge only after real layout changes.

Independent `overflow: auto` and `overflow: scroll` ancestors are also modeled,
including nested containers and the inner scroller used by standard Ionic
`ion-content`. iOS observes matched native child scroll views. On Android, supported
vertical scrollers are routed through the WebView root automatically. Chromium keeps
its normal touch and fling physics, and native follows the root scroll callback with
no per-frame bridge messages. The native view stays mounted during motion.

Android routing fails closed for horizontal scrolling, scroll snapping, direct text,
fixed or sticky descendants, and animated or translated direct children. Set
`data-native-islands-scroll="off"` on a scroll ancestor to opt out. Native islands in
that scroller remain inactive. Add `data-native-islands-scroll-interactive` to a
custom web control inside a routed scroller when it must receive pointer input;
standard links, buttons, inputs, selects, textareas, summaries, and editable elements
work automatically. Opt out when application code reads or writes that ancestor's
`scrollTop` or depends on its `scroll` event.

Fixed islands and fixed web controls participate in the same paint-order plan.
Axis-aligned translation is supported. Sticky islands, CSS zoom,
scale/rotation/skew/perspective, filters, blending or partial opacity on an island,
and complex authored clipping are unsupported. Native composition resumes when the
unsupported style is removed.

Set `isInteractive: true` when the native component owns gestures that begin in its
visible region. A composed web surface above it keeps ownership of touches in its
overlap. Touch ownership does not change during a gesture. `pointer-events: none` or
an `inert` composed ancestor prevents a new native gesture from starting.

## Web framework compatibility

Native Islands components are standard custom elements. Use the normal custom-element
setup for the web framework in your app; Native Islands does not require a
framework-specific adapter. Define components only in browser code when using
server-side rendering.

Open shadow roots and slotted islands are supported. A component that owns a closed
shadow root must expose an overlapping opaque surface through its host, because the
browser does not let Native Islands inspect the closed tree.

## API reference

The root package has one function and one TypeScript type.

### `defineNativeIsland(options)`

```ts
function defineNativeIsland(options: DefineNativeIslandOptions): CustomElementConstructor;
```

Defines the custom element named by `options.tagName` and returns its constructor.
Call it once during browser startup, before the element is used in the document.

Calling it again with the same tag, native component, and structural options refreshes
`getProperties` and `renderFallback`, then returns the existing constructor. Existing
elements use the refreshed handlers on their next ordinary update or fallback render.
It throws when structural options change after registration, when the tag is already
assigned to another native component, when another library already defined the custom
element, or when the required names are invalid.

### `DefineNativeIslandOptions`

```ts
interface DefineNativeIslandOptions {
  tagName: `${string}-${string}`;
  nativeComponent: string;
  isInteractive?: boolean;
  accessibility?: 'web' | 'native';
  requiresUnobscuredSurface?: boolean;
  observedAttributes?: readonly string[];
  observedStyles?: readonly string[];
  preserveChildren?: boolean;
  getProperties?: (element: HTMLElement) => Record<string, unknown>;
  renderFallback: (element: HTMLElement) => void;
  events?: Readonly<Record<string, string>>;
}
```

| Option                      | Required | Default           | Purpose                                                                                                                     |
| --------------------------- | -------- | ----------------- | --------------------------------------------------------------------------------------------------------------------------- |
| `tagName`                   | Yes      | —                 | Custom-element tag used in HTML. It must contain a hyphen.                                                                  |
| `nativeComponent`           | Yes      | —                 | Exact name registered by the iOS and Android factories.                                                                     |
| `renderFallback`            | Yes      | —                 | Renders the browser implementation and optional web-owned accessibility semantics. It must be safe to call more than once.  |
| `isInteractive`             | No       | `false`           | Lets the native view own gestures that begin in its visible region.                                                         |
| `accessibility`             | No       | `'web'`           | Chooses whether hidden web semantics or the native view owns accessibility. It must match the native registration.          |
| `requiresUnobscuredSurface` | No       | `false`           | Requires the native surface to remain completely unobscured. Intended for protected system surfaces that cannot be clipped. |
| `observedAttributes`        | No       | `[]`              | Attribute names whose changes trigger a coalesced native `update`.                                                          |
| `observedStyles`            | No       | `[]`              | Computed CSS property names whose changes trigger a coalesced native `update`.                                              |
| `preserveChildren`          | No       | `false`           | Keeps author-provided child elements mounted.                                                                               |
| `getProperties`             | No       | No properties     | Converts current element state into JSON-compatible properties for native `create` and `update` calls.                      |
| `events`                    | No       | No event mappings | Maps native event names to bubbling, composed DOM `CustomEvent` names.                                                      |

Most applications use a component plugin and do not call this API directly. The
component plugin defines the element and registers its native factories.

`@capacitor/native-islands/internal` is reserved for bridge packages that initialize
the same runtime with another transport. Separately bundled consuming plugins share
one page-wide runtime and registry, so application authors do not coordinate them.
Application code should not import the internal entry.

## License

MIT
